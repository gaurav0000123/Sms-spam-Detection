# Dataset Folder

Download the SMS Spam Collection dataset from the UCI Machine Learning Repository and place the downloaded data file in this folder.

The project supports either:
- `spam.csv`
- `SMSSpamCollection`
